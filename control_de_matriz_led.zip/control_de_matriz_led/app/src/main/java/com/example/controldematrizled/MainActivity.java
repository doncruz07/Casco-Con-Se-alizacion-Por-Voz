package com.example.controldematrizled;

import androidx.appcompat.app.AppCompatActivity;

import android.app.MediaRouteButton;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.media.MediaSession2;
import android.media.MediaSession2Service;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.MediaSessionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    //Atributos (variables)
    TextView txtGrabado;
    private static final int RECOGNIZE_SPEECH_ACTIVITY = 1;
    private BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    public static String address = null;
    private static final UUID BTMODULEUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    public boolean activar;
    final int handlerState = 0;
    private String strSpeech2Text;
    private Button btnConectarBt, btnDesconectarBt;
    private ConnectedThread MyConexionBT;
    private Intent intent;

    //METODOS
    //Metodo principal de la actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarAtributosVista();
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        verificarEstadoBT();

        administradorConexionBluetooth();
    }

    //Realiza la conexión con el dispositivo y permite administrarla
    private void administradorConexionBluetooth() {
        //Este código obtiene la dirección del dispositivo Bt
        Set<BluetoothDevice> pairedDevicesList = btAdapter.getBondedDevices();
        for(BluetoothDevice pairedDevice : pairedDevicesList){
            if(pairedDevice.getName().equals("CASCO")){ //DESKTOP-6II81U9
                address = pairedDevice.getAddress();
                btAdapter.cancelDiscovery();
            }

            //Función del boton conectar a bluetooth
            btnConectarBt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showToast("Estableciendo conexión");
                    activar = true;
                    onResume();
                }
            });

            //Boton que desconecta al dispositivo de Bluetooth
            btnDesconectarBt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try{
                        btSocket.close();
                        showToast("Dispositivo desconectado");
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }
            });

        }

    }

    //Método de captura para la acción del boton externo
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode != 0){
            reconocerVoz();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onActivityResult ( int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case RECOGNIZE_SPEECH_ACTIVITY:
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> speech = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    this.strSpeech2Text = speech.get(0);
                    txtGrabado.setText(strSpeech2Text);
                    enviarCodigoAccion(strSpeech2Text);
                    //Establecer una nueva conexión con el bluetooth
                    activar=true;
                    onResume();
                }
                break;
            default:
                break;
        }
    }

    //Metodo que lanza el intent para iniciar el reconocimiento de voz mediande el boton hardware externo
    public void reconocerVoz(){

        Intent intentActionRecognizeSpeech = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        // Configura el Lenguaje (Español-México)
        intentActionRecognizeSpeech.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL, "es-MX");
        try {
            startActivityForResult(intentActionRecognizeSpeech, RECOGNIZE_SPEECH_ACTIVITY);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(), "Tú dispositivo no soporta el reconocimiento por voz",
                    Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo que lanza el intent para iniciar el reconocimiento de voz mediande el boton de UI
    public void onClickReconocerVoz (View v){
        reconocerVoz();
    }


    //Creando el objeto Socket
    public BluetoothSocket createBluetoothSocket (BluetoothDevice device) throws IOException {
        return device.createRfcommSocketToServiceRecord(BTMODULEUUID);
    }

    private void verificarEstadoBT() {
        if (!btAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }
    }

    //Inicializar y hacer uso del socket
    public void onResume() {
        super.onResume();
        btAdapter.cancelDiscovery();
        if (activar) {
            BluetoothDevice device = btAdapter.getRemoteDevice(address);

            try {
                btSocket = createBluetoothSocket(device);

            } catch (IOException e) {
                Toast.makeText(getBaseContext(), "La creacción del Socket fallo", Toast.LENGTH_LONG).show();
            }

            // Establece la conexión con el socket Bluetooth.
            try {
                btSocket.connect();
                if(btSocket.isConnected()) {
                    showToast("Conexión establecida");
                }
            } catch (IOException e) {
                try {
                    btSocket.close();
                } catch (IOException e2) {
                }
            }
            MyConexionBT = new ConnectedThread(btSocket);
            MyConexionBT.start();
        }

    }

    //Este código nos provee la configuración nesesaria para la comunicación con Arduino
    public class ConnectedThread extends Thread{
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        Handler bluetoothIn;
        final int handlerState=0;

        public ConnectedThread(BluetoothSocket socket) {

            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {

            }
            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            btAdapter.cancelDiscovery();
            byte[] buffer = new byte[256];
            int bytes;

            // Se mantiene en modo escucha para determinar el ingreso de datos
            while (true) {
                try {
                    bytes = mmInStream.read(buffer);
                    String readMessage = new String(buffer, 0, bytes);
                    // Envia los datos obtenidos hacia el evento via handler
                    bluetoothIn.obtainMessage(handlerState, bytes, -1, readMessage).sendToTarget();
                } catch (IOException e) {
                    break;
                }
            }
        }


        //Envio de trama
        public void write(String input) {
            try {
                mmOutStream.write(input.getBytes());
            } catch (IOException e) {
                //si no es posible enviar datos se cierra la conexión
                Toast.makeText(getBaseContext(), "La conexión falló", Toast.LENGTH_LONG).show();
                //finish();
            }
        }
    }

    //Se toma la accion dictada por voz y se envia un codigo de accion al controlador
    public void enviarCodigoAccion(String accion){
        String codAccion="";

        try{
            switch (accion){
                case "derecha":
                    MyConexionBT.write("2");
                    break;
                case "izquierda":
                    MyConexionBT.write("1");
                    break;
                case "parar":
                    MyConexionBT.write("3");
                    break;
                default:
                    MyConexionBT.write("0");
                    break;
            }
        }catch (Exception e){
            showToast("No hay una conexión establecida");
        }

    }

    //Relaciona los atributos de vista con un objeto de esta clase
    public void inicializarAtributosVista(){
        txtGrabado = findViewById(R.id.txtAcciones);
        btnConectarBt = findViewById(R.id.btnConectarBt);
        btnDesconectarBt = findViewById(R.id.btnDesconectarBt);
    }

    //Notificar por pantalla un mensaje corto
    private void showToast(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }

}